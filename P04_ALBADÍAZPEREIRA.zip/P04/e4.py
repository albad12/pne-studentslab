import socket
import termcolor
from pathlib import Path

IP = "127.0.0.1"
PORT = 8080

def process_client(s):
    req_raw = s.recv(2000)
    req = req_raw.decode()
    print("Message FROM CLIENT: ")
    lines = req.split('\n')
    req_line = lines[0]
    path = req_line.split(" ")
    print("Request line: ", end="")
    termcolor.cprint(req_line, "green")
    if path[1] == "/info/G":
        body = Path("G.html").read_text()
    elif path[1] == "/info/T":
        body = Path("T.html").read_text()
    elif path[1] == "/info/A":
        body = Path("A.html").read_text()
    elif path[1] == "/info/C":
        body = Path("C.html").read_text()
    else:
        body = " "
    status_line = "HTTP/1.1 200 OK\n"
    header = "Content-Type: text/html\n"
    header += f"Content-Length: {len(body)}\n"
    response_msg = status_line + header + "\n" + body
    cs.send(response_msg.encode())
ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
ls.bind((IP, PORT))
ls.listen()
print("Adenine server configured!")
while True:
    print("Waiting for clients....")
    try:
        (cs, client_ip_port) = ls.accept()
    except KeyboardInterrupt:
        print("Server stopped!")
        ls.close()
        exit()
    else:
        process_client(cs)
        cs.close()