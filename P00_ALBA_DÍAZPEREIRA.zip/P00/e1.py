from Seq0 import seq_ping

seq_ping()