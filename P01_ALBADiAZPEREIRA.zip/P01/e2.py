from Seq1 import Seq

print("-----| Practice 1, Exercise 2 |------")
seq1 = Seq()
seq2 = Seq("TATAC")

print("")
print(f"Sequence 1: {seq1}")
print(f"Sequence 2: {seq2}")

