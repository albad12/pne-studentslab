from Seq1 import *

print("-----| Practice 1, Exercise 6 |------")

s1 = Seq()
s2 = Seq("ACTGA")
s3 = Seq("Invalid sequence")

lst = [s1, s2, s3]
n = 1
for seq in lst:
    print("Sequence", n, ": (Length:", seq.len(), ")", seq, "\nBases:", seq.count_dict() )
    n += 1